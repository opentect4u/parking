// const mysql = require('mysql');
const mysql = require('mysql2');
const logger = require('../model/LoggerModel');

// const db = mysql.createPool({
//     connectionLimit: 10,
//     host: "synwebmysql-1.c98wsim6cvnq.ap-south-2.rds.amazonaws.com",
//     user: "myparking",
//     password: "Rvpf657_5#Syn",
//     database: "myparking",
// });

// const db = mysql.createPool({
//     connectionLimit: 10,
//     host: "localhost",
//     user: "root",
//     password: "",
//     database: "hertz_parking",
// });

const db = mysql.createPool({
    connectionLimit: 10,
    host: "synwebmysql-1.c98wsim6cvnq.ap-south-2.rds.amazonaws.com",
    user: "vpark_user",
    password: "vpark@8765",
    database: "vpark",
});

db.getConnection((err, connection) => {
    if (err) {
        logger.error(err);
        console.log(err);
    }
    connection.release();
    return;
});

module.exports = db;